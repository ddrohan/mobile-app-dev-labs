package ie.cm.activities;

import ie.cm.R;
import android.os.Bundle;
import android.view.View;

public class Home extends Base {
   	
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
    }

	  @Override
		protected void onResume() {
		  super.onResume();		
			
		}

	public void add(View v) {		
			 goToActivity(this,Add.class,null);
			}
}