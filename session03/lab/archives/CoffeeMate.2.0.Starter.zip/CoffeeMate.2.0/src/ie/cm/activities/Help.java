package ie.cm.activities;

import ie.cm.R;
import android.os.Bundle;

public class Help extends Base {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.help); 
	}
}
