package ie.cm.activities;

import ie.cm.R;
import ie.cm.models.Coffee;
import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.Toast;

public class Edit extends Base {
	private Context context;
	private Boolean isFavourite;
	private Coffee aCoffee;
	private ImageView favouriteImage;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		context = this;

	}

	private Coffee getCoffeeObject(int id) {

		for (Coffee c : coffeeList)
			if (c.getCoffeeId() == id)
				return c;

		return null;
	}

	private int getCoffeeIndex(Coffee obj) {

		for (Coffee c : coffeeList)
			if (c.getCoffeeId() == obj.getCoffeeId())
				return coffeeList.indexOf(c);

		return -1;
	}

	public void update(View v) {

		String coffeeName = getEditString(R.id.nameEditText);
		String coffeeShop = getEditString(R.id.shopEditText);
		double ratingValue = getRatingBarValue(R.id.coffeeRatingBar);
		double coffeePrice;

		try {
			coffeePrice = getEditDouble(R.id.priceEditText);
		} catch (NumberFormatException e) {
			coffeePrice = 0.0;
		}

		if ((coffeeName.length() > 0) && (coffeeShop.length() > 0) && (getEditString(R.id.priceEditText).length() > 0)) {
			aCoffee.setCoffeeName(coffeeName);
			aCoffee.setShop(coffeeShop);
			aCoffee.setPrice(coffeePrice);
			aCoffee.setRating(ratingValue);

			// Update coffee & return home

		} else
			toastMessage("You must Enter Something for Name and Shop");

	}
}
