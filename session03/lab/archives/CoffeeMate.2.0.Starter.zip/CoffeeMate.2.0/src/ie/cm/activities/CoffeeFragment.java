package ie.cm.activities;

import ie.cm.coffeeadapters.CoffeeListAdapter;
import ie.cm.models.Coffee;
import ie.cm.R;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.ListFragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ListView;

public class CoffeeFragment  extends ListFragment implements  OnClickListener
{ 
  protected Base 						activity;
  protected static CoffeeListAdapter 	listAdapter;
  protected ListView 					listView;

@Override
  public void onAttach(Activity activity)
  {
    super.onAttach(activity);
    this.activity = (Base) activity;   
  }

  @Override
  public void onCreate(Bundle savedInstanceState)
  {
    super.onCreate(savedInstanceState);

  }
     
  @Override
  public void onStart()
  {
    super.onStart();
  }

  @Override
  public void onClick(View view)
  {
  } 
}

  