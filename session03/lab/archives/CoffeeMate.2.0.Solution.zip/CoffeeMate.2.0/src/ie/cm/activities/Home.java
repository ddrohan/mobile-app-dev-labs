package ie.cm.activities;

import ie.cm.R;
import ie.cm.models.Coffee;
import android.os.Bundle;
import android.view.View;

public class Home extends Base {
		
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        //Comment out after first run of app
        setupCoffees();	
    }

	  @Override
		protected void onResume() {
		  super.onResume();		
			
		  coffeeFragment = new CoffeeFragment();
		  getFragmentManager().beginTransaction()
		  					  .add(R.id.fragment_layout, coffeeFragment)
		  					  .commit();
		}

	public void add(View v) {
		goToActivity(this,Add.class,null);
	}
	
	public void setupCoffees(){
		coffeeList.add(new Coffee("Standard Black", "Some Shop",2.5,1.99,0));
		coffeeList.add(new Coffee("Regular Joe", "Joe's Place",3.5,2.99,1));
		coffeeList.add(new Coffee("Espresso", "Ardkeen Stores",4.5,1.49,1));
	}
}