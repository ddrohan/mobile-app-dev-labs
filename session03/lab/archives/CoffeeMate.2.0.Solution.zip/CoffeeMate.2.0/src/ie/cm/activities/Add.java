package ie.cm.activities;

import ie.cm.models.Coffee;
import ie.cm.R;
import android.os.Bundle;
import android.view.View;

public class Add extends Base {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.add);
	}

	public void add(View v) {

		String coffeeName = 	getEditString(R.id.nameEditText);
		String coffeeShop = 	getEditString(R.id.shopEditText);
		double ratingValue = 	getRatingBarValue(R.id.coffeeRatingBar);
		double coffeePrice;

		try {
			coffeePrice = getEditDouble(R.id.priceEditText);
		} catch (NumberFormatException e) {
			coffeePrice = 0.0;
		}

		if ((coffeeName.length() > 0) && (coffeeShop.length() > 0)
				&& (getEditString(R.id.priceEditText).length() > 0)) {
			Coffee c = new Coffee(coffeeName, coffeeShop, ratingValue,
					coffeePrice, 0);
			coffeeList.add(c);
			goToActivity(this,Home.class, null);
		} else
			toastMessage("You must Enter Something for Name and Shop");
	}
}
