package ie.cm.models;

import java.io.Serializable;

public class Coffee implements Serializable
{
	private static int autoid = 1;
	private int coffeeId;
	private String coffeeName;
	private String shop;
	private double rating;
	private double price;
	private int favourite;
	
	public Coffee() {}
	
	public Coffee(String coffeeName, String shop, double rating,
			double price,int fav) {
		super();
		this.coffeeId = autoid++;
		this.coffeeName = coffeeName;
		this.shop = shop;
		this.rating = rating;
		this.price = price;
		this.favourite = fav;
	}

	public int getCoffeeId() {
		return coffeeId;
	}

	public void setCoffeeId(int coffeeId) {
		this.coffeeId = coffeeId;
	}

	public String getCoffeeName() {
		return coffeeName;
	}

	public void setCoffeeName(String coffeeName) {
		this.coffeeName = coffeeName;
	}

	public String getShop() {
		return shop;
	}
	
	public void setShop(String shop) {
		this.shop = shop;
	}

	public double getRating() {
		return rating;
	}

	public void setRating(double rating) {
		this.rating = rating;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public int getFavourite() {
		return this.favourite;
	}

	public void setFavourite(int fav) {
		this.favourite = fav;
	}
	
	@Override
	public String toString() {
		return "Coffee [coffeeid=" + coffeeId + "],[coffeeName=" + coffeeName
				+ ", shop =" + shop + ", rating=" + rating + ", price=" + price
				+ ", fav =" + favourite + "]";
	}
}
