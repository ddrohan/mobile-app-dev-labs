package ie.cm.activities;

import ie.cm.R;
import ie.cm.main.CoffeeMateApp;
import android.app.Activity;
import android.app.Dialog;
import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextWatcher;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.AdapterView.OnItemSelectedListener;

public class Base extends Activity {

	public CoffeeMateApp 	app; 
	protected Bundle 		activityInfo;
	public Fragment 		coffeeFragment;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		app = (CoffeeMateApp) getApplication();
	}

	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	public Fragment getCoffeeFragment() {
		return coffeeFragment;
	}
	
	protected void goToActivity(Activity current,Class<? extends Activity> activity,
			 Bundle bundle) {
		Intent newActivity = new Intent(current, activity);

		if (bundle != null)
			newActivity.putExtras(bundle);

		current.startActivity(newActivity);
	}

	private void openInfoDialog(Activity current) {
		Dialog dialog = new Dialog(current);
		dialog.setTitle("About CoffeeMate");
		dialog.setContentView(R.layout.info);

		TextView currentVersion = (TextView) dialog
				.findViewById(R.id.versionTextView);
		currentVersion.setText(getString(R.string.version));

		dialog.setCancelable(true);
		dialog.setCanceledOnTouchOutside(true);
		dialog.show();
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case R.id.home:
			goToActivity(this,Home.class, null);
			break;
		case R.id.help:
			goToActivity(this,Help.class,  null);
			break;
		case R.id.info:
			openInfoDialog(this);
			break;
		}
		return true;
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		MenuInflater i = getMenuInflater();
		i.inflate(R.menu.optionsmenu, menu);
		return super.onCreateOptionsMenu(menu);
	}

	public EditText getEditText(int id) {
		return ((EditText) findViewById(id));
	}

	protected String getEditString(int id) {
		return (getEditText(id)).getText().toString();
	}

	protected void setEditString(int id, String str) {
		(getEditText(id)).setText(str);
	}

	protected void setTextViewString(int id, String str) {
		((TextView) findViewById(id)).setText(str);
	}

	protected void setEditDouble(int id, Double d) {
		((EditText) findViewById(id)).setText(d.toString());
	}

	protected double getRatingBarValue(int id) {
		RatingBar bar = (RatingBar) findViewById(id);
		return bar.getRating();
	}

	protected void setRatingBarValue(int id, float d) {
		RatingBar bar = (RatingBar) findViewById(id);
		bar.setRating(d);
	}

	protected double getEditDouble(int id) {
		return Double.parseDouble(getEditString(id));
	}

	protected Button getButton(int id) {
		return (Button) findViewById(id);
	}

	protected CheckBox getCheckBox(int id) {
		return (CheckBox) findViewById(id);
	}

	public void setSpinnerListener(int id, int data,
			OnItemSelectedListener listener) {
		ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter
				.createFromResource(this, data,
						android.R.layout.simple_spinner_item);
		spinnerAdapter
				.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		((Spinner) findViewById(id)).setAdapter(spinnerAdapter);
		((Spinner) findViewById(id)).setOnItemSelectedListener(listener);
	}

	protected void setEditTextListener(int id, TextWatcher listener) {
		((EditText) findViewById(id)).addTextChangedListener(listener);
	}

	protected void toastMessage(String s) {
		Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
	}
}
