package ie.cm.activities;

import ie.cm.R;
import android.os.Bundle;

public class Favourites extends Base {
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.favourites);
	}
	@Override
	protected void onResume() {
		super.onResume();

		coffeeFragment = new CoffeeFragment();
		getFragmentManager().beginTransaction()
				.add(R.id.fragment_layout, coffeeFragment).commit();
	}
}
