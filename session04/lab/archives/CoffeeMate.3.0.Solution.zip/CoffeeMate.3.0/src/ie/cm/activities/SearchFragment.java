package ie.cm.activities;

import ie.cm.R;
import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

public class SearchFragment extends CoffeeFragment 
								implements OnItemSelectedListener, TextWatcher {
	@Override
	public void onAttach(Activity activity) {
		super.onAttach(activity);
	}

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		ArrayAdapter<CharSequence> spinnerAdapter = 
				ArrayAdapter.createFromResource(activity, 
												R.array.coffeeTypes, 
												android.R.layout.simple_spinner_item);

		spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

		Spinner spinner = ((Spinner) activity.findViewById(R.id.searchCoffeeTypeSpinner));
		spinner.setAdapter(spinnerAdapter);
		spinner.setOnItemSelectedListener(this);

		activity.getEditText(R.id.searchCoffeeNameEditText).addTextChangedListener(this);
	}

	@Override
	public void onStart() {
		super.onStart();
	}

	@Override
	public void onItemSelected(AdapterView<?> adapterView, View arg1, int position, long arg3) {
	
		String selected = adapterView.getItemAtPosition(position).toString();

		if (selected != null) {
			if (selected.equals("All Types")) {
				coffeeFilter.setFilter("all");
			} else if (selected.equals("Favourites")) {
				coffeeFilter.setFilter("favourites");
			}
			coffeeFilter.filter("");
		}
	}
	
	@Override
	public void onTextChanged(CharSequence s, int start, int before, int count) {
		coffeeFilter.filter(s);
	}
	@Override
	public void onNothingSelected(AdapterView<?> arg0) {
	}

	@Override
	public void afterTextChanged(Editable s) {
	}

	@Override
	public void beforeTextChanged(CharSequence s, int start, int count, int after) {
	}


}